// Example JS functionality (Form validation or anything else)
document.querySelector('form').addEventListener('submit', function(e) {
    const phoneNumber = document.getElementById('phone_number').value;
    if (!phoneNumber) {
        e.preventDefault();
        alert("Please enter your phone number!");
    }
});
